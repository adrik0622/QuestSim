# QuestSim director guide

## The first creative contract

Choose these before investing in assets or terrain infrastructure:

| Decision | Proposed starting assumption | Why it matters |
| --- | --- | --- |
| Camera | Fixed/top-down or limited-angle | Determines visual pipeline, occlusion, verticality and aiming. |
| Construction | Modular grid walls/doors/containers | Proves base building without excavation technology. |
| Digging | Deferred | If mandatory, evaluate Luanti/block voxels before committing to Godot terrain. |
| Multiplayer | 2 clients first, 2-8 prototype | Scattered players multiply active world regions. |
| Simulation detail | Identity everywhere, coarse far behavior | Defines what “all zombies tracked” means. |
| World time | Pause when empty | Prevents unattended co-op collapse by default. Autonomy tests deliberately override pause. |
| Disconnect | Explicit policy; vulnerable body is the minimal experiment | Safe suspension and AI takeover change fairness and implementation. Decide before long campaigns. |
| Capacity | Actual weekly engineering hours and target machines | Estimates depend on experience, availability and hardware coverage. |

These are provisional choices for discussion. Your intent overrides defaults. Agents should not silently decide harsh death, logout, replenishment or story-intervention rules.

## Define meaningful consequences

Replace an untestable promise that every action deeply changes the world with this contract: material actions change persistent state; important changes can propagate across systems; players can discover some causal connections.

Three candidate test stories:

1. Taking depot food changes stockpiles, scavenging assignments, trade requests and trust if witnesses identify the theft.
2. Barricading a route changes travel, delivery timing and where a horde encounters survivors.
3. Helping a rival faction changes resources and relationships, opening one alliance while closing another.

The faction response must use real resources and members. The director may reveal or connect opportunities; it cannot invent consequences after the fact merely to make the player important.

## Long character arcs

Begin with identity, relationships, reputation, commitments, debts, injuries and faction membership that survive sessions. Add authored templates that respond to these facts. An arc can end in failure, retirement or death; decide whether a new character inherits a faction/base legacy.

“Player like NPC” should mean shared rules, not identical handling of human absence. Sleeping bodies, protected logout and AI caretakers make different games. Decide consciously.

## Weekly review

Ask for one runnable build and a short observed/assumed/deferred report. Use the same seed/save to see progress. Spend approximately 30 minutes:

1. Inspect faction wants and resources.
2. Let the world act without intervention.
3. Make one material change with player A while player B is elsewhere.
4. Discover a resulting opportunity; invalidate one prerequisite with the other player.
5. Build at a doorway, inspect navigation, reconnect and reload.
6. Explain what happened without relying only on developer logs.

Judge whether the result creates an interesting choice, remains understandable, respects the other player's actions and persists correctly. A million moving dots does not demonstrate these things.

## Prototype gates

- After the first two-week attempt: is the shared authority loop reliable enough to build on?
- At 6-10 weeks: are persistence, independent activity and a basic consequence loop credible? Revise scope before investing further.
- At the integrated slice: do human playtests justify more content and scale?
- Before adopting GPU or voxels: did the whole integrated workload improve or become uniquely possible, with acceptable portability and maintenance?

For an experienced solo developer at full-time capacity, a bounded slice is a provisional 5-10 month project including contingency. A skilled 2-3 engineer team might reach comparable scope in 3-6 months. These are planning judgments; they exclude a finished commercial game. AI assistance does not eliminate integration and playtesting. Re-estimate from observed throughput.

## Keep, change or stop

A useful experiment can reject a direction. Stop GPU integration if its end-to-end gain is immaterial. Stop terrain expansion if edited navigation is unstable. Reduce story complexity if facts conflict. Fix state duplication before adding any feature.

Do not lower all ambitions at once. Preserve the core feeling: an independent world, shared rules, lasting consequences and understandable opportunities. Reduce map size, actor detail, art complexity and feature count first.

## Decisions to revisit after evidence

- Does offscreen combat feel fair and preserve important outcomes?
- Can factions recover, or can the world become permanently unplayable?
- Should zombies replenish through infection/migration? What are the explicit limits?
- Are many floors or free-camera 3D essential enough to justify added work?
- Is the director allowed to initiate legal events, or only surface existing opportunities?
- Which code mods are trusted, and what compatibility promises can actually be maintained?
