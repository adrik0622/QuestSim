# Current task: Q00 / bootstrap the first playable path

Status: proposed; game implementation has not begun in this planning workspace.

Outcome: establish the actual repository/toolchain, write reproducible build/run commands, and select the first tiny executable task.

Provisional choices: Godot .NET/C#; CPU authority; fixed camera; modular building; two clients initially; no digging; no GPU dependency. Choices are provisional, not confirmed director decisions.

Steps:
1. Inspect the real repository and installed tools. Preserve existing code and instructions. If empty, create only the minimum project needed to launch a placeholder room.
2. Pin the actual compatible engine/runtime versions. Record real commands and prerequisites in RUNBOOK.md. Do not claim remote machines are tested.
3. Run the available launch/build check. Reduce Q01 into one next outcome: local room, headless startup, then two clients; retain external platform exports as explicit checks.
4. Replace STATE.md's planning-only status with observed repository state. Record unresolved camera/absence/hardware decisions without blocking independent setup work.

Allowed changes: minimal project scaffolding and these operational docs. Existing repository instructions take precedence.
Done: a real launch/build result or exact prerequisite blocker, accurate runbook, and one bounded next task.
Exclude: population scale, GPU, voxel terrain, generic mod framework, art production, full backlog implementation.
Delegation: none for this bootstrap.
