# QuestSim runbook

The implementation repository and toolchain have not been inspected. Commands below are deliberately unpopulated; the bootstrap agent must discover and verify them rather than inventing a successful setup.

Record only actual project commands:

| Operation | Verified command / prerequisite | Evidence |
| --- | --- | --- |
| Toolchain versions | Unknown | Not checked |
| Build | Unknown | Not run |
| Run client | Unknown | Not run |
| Run CPU headless server | Unknown | Not run |
| Start two independent clients | Unknown | Not run |
| Targeted tests | Unknown | Not run |
| Required integration checks | Unknown | Not run |
| Desktop exports | Unknown | Not run |

Add the smallest reliable checks first. Keep full noisy logs outside routine context. Document actual flags, working directory and fixture/seed where reproducibility requires them. Update when commands change, not on every task.
